package ar.edu.davinci.dv_ds_20241c_g22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DvDs20241cG22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
