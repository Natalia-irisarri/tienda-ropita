package ar.edu.davinci.dv_ds_20241c_g22;
public interface Constantes {
	public static final String FORMATO_FECHA = "dd-MM-yyyy";
}

