package ar.edu.davinci.dv_ds_20241c_g22.controller.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VentaEfectivoResponse extends VentaResponse {

}

