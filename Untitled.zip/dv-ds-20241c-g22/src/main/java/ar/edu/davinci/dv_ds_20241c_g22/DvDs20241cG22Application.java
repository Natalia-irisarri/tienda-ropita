package ar.edu.davinci.dv_ds_20241c_g22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DvDs20241cG22Application {

	public static void main(String[] args) {
		SpringApplication.run(DvDs20241cG22Application.class, args);
	}

}
